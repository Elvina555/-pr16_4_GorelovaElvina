﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr16_4
{
    class Nasel
    {
        public string Name { get; set; }
        public long Ludi { get; set; }
        public Nasel (string name, long ludi)
        {
            Name = name;
            Ludi = ludi;
        }
    }
}
