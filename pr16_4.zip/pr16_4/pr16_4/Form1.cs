﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr16_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Nasel> n = new List<Nasel>();
        List<Nasel> n1 = new List<Nasel>();
        private void FindPeaple(object sender, EventArgs e)
        {
            if (File.Exists("file.txt"))
            {
                string[] file = File.ReadAllLines("file.txt");
                if (file.Length != 1)
                {
                    foreach(string f in file)
                    {
                        char a1 = f.First(a => char.IsDigit(a));
                        int b = f.IndexOf(a1);
                        string name = f.Substring(0, b);
                        string p = f.Substring(b);
                        long na = long.Parse(p);
                        n.Add(new Nasel(name, na));
                    }
                    if (int.TryParse(textBox1.Text.Replace(" ", ""), out int n1))
                    {
                        long nasel = long.Parse(textBox1.Text.Replace(" ", ""));
                        if (nasel > 0)
                        {
                            var nas = n.Where(a => a.Ludi > nasel).OrderBy(a => a.Name.Length).ToList();
                            listBox1.Items.Clear();
                            foreach (Nasel n in nas)
                            {
                                listBox1.Items.Add(n.Name + " " + n.Ludi);
                            }
                        }
                        else MessageBox.Show("Численость населения не может быть отрицательной");
                    }
                    else MessageBox.Show("Введите корректно");
                }
                else MessageBox.Show("Файле что-то не так");
            }
            else MessageBox.Show("Файл не сущестует");
        }

        private void SortofLenght(object sender, EventArgs e)
        {
            if (File.Exists("file.txt"))
            {
                string[] file = File.ReadAllLines("file.txt");
                if (file.Length != 1)
                {
                    foreach (string f in file)
                    {
                        char a1 = f.First(a => char.IsDigit(a));
                        int b = f.IndexOf(a1);
                        string name = f.Substring(0, b);
                        string p = f.Substring(b);
                        long na = long.Parse(p);
                        n1.Add(new Nasel(name, na));
                    }
                    var sort = n1.OrderBy(a => a.Name.Length).ThenBy(a => a.Name).ToList();
                    listBox2.Items.Clear();
                    foreach(Nasel s in sort)
                    {
                        listBox2.Items.Add(s.Name + " " + s.Ludi);
                    }
                }
                else MessageBox.Show("Файле что-то не так");
            }
            else MessageBox.Show("Файл не сущестует");
        }   
    }
}
